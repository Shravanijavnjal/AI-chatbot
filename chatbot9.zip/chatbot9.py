import tkinter as tk
from tkinter import scrolledtext, ttk
import re
import google.generativeai as genai  # Import Gemini API library

# Configure Gemini API
GENAI_API_KEY = "AIzaSyDt2Y_JOXTElOHqdBPIgMPAHP28cekk08U"  
genai.configure(api_key=GENAI_API_KEY)

def is_math_expression(query):
    """Check if the query is a mathematical expression."""
    return re.fullmatch(r'[0-9+\-*/(). ]+', query) is not None

def evaluate_math_expression(expression):
    """Safely evaluate mathematical expressions."""
    try:
        return str(eval(expression))
    except Exception:
        return "Sorry, I couldn't calculate that."

def ask_gemini(user_input):
    """Query the Gemini AI model for responses."""
    try:
        model = genai.GenerativeModel("gemini-2.0-flash")
        response = model.generate_content(user_input)
        return response.text if response else "I'm not sure about that."
    except Exception as e:
        return f"Error fetching response from Gemini: {e}"

def get_response():
    """Handles user input and generates chatbot response."""
    user_input = user_entry.get().strip()

    if user_input.lower() == "exit":
        root.destroy()  # Close the chatbot window

    if user_input:
        chat_window.config(state=tk.NORMAL)
        chat_window.insert(tk.END, f"\nYou: {user_input}\n", "user")
        
        if is_math_expression(user_input):
            response = evaluate_math_expression(user_input)
        else:
            response = ask_gemini(user_input)  # Get answer from Gemini
        
        chat_window.insert(tk.END, f"Chatbot: {response}\n", "bot")
        chat_window.config(state=tk.DISABLED)
        chat_window.yview(tk.END)  # Auto-scroll
        user_entry.delete(0, tk.END)

# Create GUI Window
root = tk.Tk()
root.title("Smart Chatbot - P R Pote College of Engineering")
root.geometry("450x550")
root.configure(bg="#1e1e1e")
root.resizable(False, False)

# Header Label
header_label = tk.Label(root, text="P R Pote College of Engineering\nWelcome to AI chatbot", font=("Arial", 14, "bold"), bg="#1e1e1e", fg="white")
header_label.pack(pady=5)

# Chat Display Area
chat_window = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=50, height=20, bg="#2b2b2b", fg="white", font=("Arial", 12))
chat_window.config(state=tk.DISABLED)
chat_window.tag_configure("user", foreground="#00ff7f", font=("Arial", 12, "bold"))
chat_window.tag_configure("bot", foreground="#00bfff", font=("Arial", 12))
chat_window.pack(pady=10, padx=10)

# Input Field
user_entry = tk.Entry(root, width=45, font=("Arial", 12), bg="#3b3b3b", fg="white", insertbackground="white")
user_entry.pack(pady=5, padx=10)
user_entry.bind("<Return>", lambda event: get_response())  # Allow Enter key

# Button Frame
button_frame = tk.Frame(root, bg="#1e1e1e")
button_frame.pack(pady=5)

# Send Button
send_button = ttk.Button(button_frame, text="Send", command=get_response, style="TButton")
send_button.grid(row=0, column=0, padx=5)

# Close Button
close_button = ttk.Button(button_frame, text="Close", command=root.destroy, style="TButton")
close_button.grid(row=0, column=1, padx=5)

# Run GUI
root.mainloop()
